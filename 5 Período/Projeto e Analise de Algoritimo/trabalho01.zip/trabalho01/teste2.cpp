#include <iostream>
#include <vector>
#include <stack>
#include <ctime>
#include <functional>
#include <chrono>
#include <algorithm>
#include <math.h>

using namespace std;
class Graph {
public:
    long vertices;
    vector<vector<long>> adj_list;

    Graph(long v) : vertices(v), adj_list(v) {
        srand(time(NULL));

        if(vertices <= 1000){
             for (long i = 0; i < vertices - 1; ++i) {
            addEdge(i, i + 1);
        }
        }else{
            // Adiciona arestas aleatórias
        for (long i = 0; i < vertices/2; ++i) {
            long u, v;
            do {
                u = rand() % vertices;
                v = rand() % vertices;
            } while (u == v || edgeExists(u, v));

            addEdge(u, v);
        }
        }

        
    }

    void addEdge(long u, long v) {
        adj_list[u].push_back(v);
        adj_list[v].push_back(u);
    }

    bool edgeExists(long u, long v) {
        for (const long neighbor : adj_list[u]) {
            if (neighbor == v) {
                return true;
            }
        }
        return false;
    }

    void naiveBridgeDetection();
    void tarjanBridgeDetection();
    void fleuryAlgorithm();
};
void Graph::naiveBridgeDetection() {
    vector<pair<long, long>> bridges;

    for (long u = 0; u < vertices; ++u) {
        for (long v : adj_list[u]) {
            // Criar uma cópia temporária do grafo
            Graph tempGraph = *this;

            // Remover a aresta temporariamente
            tempGraph.adj_list[u].erase(remove(tempGraph.adj_list[u].begin(), tempGraph.adj_list[u].end(), v), tempGraph.adj_list[u].end());
            tempGraph.adj_list[v].erase(remove(tempGraph.adj_list[v].begin(), tempGraph.adj_list[v].end(), u), tempGraph.adj_list[v].end());

            vector<bool> visited(vertices, false);
            stack<long> stack;

            stack.push(0);
            visited[0] = true;

            while (!stack.empty()) {
                long current = stack.top();
                stack.pop();

                for (long neighbor : tempGraph.adj_list[current]) {
                    if (!visited[neighbor]) {
                        stack.push(neighbor);
                        visited[neighbor] = true;
                    }
                }
            }

            // Verificar a conectividade usando uma única busca em profundidade
            if (count(visited.begin(), visited.end(), true) != vertices) {
                bridges.emplace_back(u, v);
            }
        }
    }

    // // Print bridges
    // if (!bridges.empty()) {
    //     cout << "Naive Bridges: ";
    //     for (auto bridge : bridges) {
    //         cout << "(" << bridge.first << " - " << bridge.second << ") ";
    //     }
    //     cout << endl;
    // } else {
    //     cout << "No Naive Bridges Found" << endl;
    // }
}

void Graph::tarjanBridgeDetection() {
    vector<pair<long, long>> bridges;
    vector<long> discovery_time(vertices, -1);
    vector<long> low(vertices, -1);
    vector<long> parent(vertices, -1);
    vector<bool> visited(vertices, false);
    long time = 0;

    function<void(long)> dfs = [&](long u) {
        visited[u] = true;
        time++;
        discovery_time[u] = low[u] = time;

        for (long v : adj_list[u]) {
            if (!visited[v]) {
                parent[v] = u;
                dfs(v);
                low[u] = min(low[u], low[v]);

                if (low[v] > discovery_time[u]) {
                    bridges.emplace_back(u, v);
                }
            } else if (v != parent[u]) {
                low[u] = min(low[u], discovery_time[v]);
            }
        }
    };

    for (long node = 0; node < vertices; ++node) {
        if (!visited[node]) {
            dfs(node);
        }
    }

    // Print bridges
    if (!bridges.empty()) {
        cout << "Tarjan Bridges: ";
        for (auto bridge : bridges) {
            cout << "(" << bridge.first << " - " << bridge.second << ") ";
        }
        cout << endl;
    } else {
        cout << "No Tarjan Bridges Found" << endl;
    }
}

void Graph::fleuryAlgorithm() {
    vector<long> eulerian_path;
    Graph graph_copy = *this;

    function<bool(long, long)> isValidEdge = [&](long u, long v) {
        return graph_copy.adj_list[u].size() == 1 || (u == v && graph_copy.adj_list[u].size() > 1);
    };

    function<void(long)> dfsFleury;
    dfsFleury = [&](long u) {
        for (long v : graph_copy.adj_list[u]) {
            if (isValidEdge(u, v)) {
                graph_copy.adj_list[u].erase(remove(graph_copy.adj_list[u].begin(), graph_copy.adj_list[u].end(), v), graph_copy.adj_list[u].end());
                graph_copy.adj_list[v].erase(remove(graph_copy.adj_list[v].begin(), graph_copy.adj_list[v].end(), u), graph_copy.adj_list[v].end());
                dfsFleury(v);
            }
        }
        eulerian_path.push_back(u);
    };

    long start_node = 0;
    dfsFleury(start_node);

    // Print Eulerian Path
    if (eulerian_path.size() == vertices) {
        cout << "Eulerian Path Found" << endl;
    } else {
        cout << "No Eulerian Path Found" << endl;
    }
}

int main() {
    srand(time(NULL));

    for (long vertices : {100, 1000, 10000, 100000}) {
        Graph graph(vertices);

        cout << "Graph with " << vertices << " vertices:" << endl;

        // Imprimir o grafo
        //graph.printGraph();

        // Medir o tempo para a detecção ingênua de pontes
        clock_t naiveTotalTime = 0;
        int naiveNumRuns = 1; // Número de execuções para calcular a média
        for (int run = 0; run < naiveNumRuns; ++run) {
            clock_t naiveStart = clock();
            graph.naiveBridgeDetection();
            clock_t naiveEnd = clock();
            naiveTotalTime += (naiveEnd - naiveStart);
        }
        cout << "Naive method - Average Time: " << double(naiveTotalTime) / CLOCKS_PER_SEC / naiveNumRuns * 1000000 << " microseconds" << endl;

        // Medir o tempo para a detecção de pontes de Tarjan
        clock_t tarjanTotalTime = 0;
        int tarjanNumRuns = 1;
        for (int run = 0; run < tarjanNumRuns; ++run) {
            clock_t tarjanStart = clock();
            graph.tarjanBridgeDetection();
            clock_t tarjanEnd = clock();
            tarjanTotalTime += (tarjanEnd - tarjanStart);
        }
        cout << "Tarjan method - Average Time: " << double(tarjanTotalTime) / CLOCKS_PER_SEC / tarjanNumRuns * 1000000 << " microseconds" << endl;

        // Medir o tempo para o algoritmo de Fleury
        clock_t fleuryTotalTime = 0;
        int fleuryNumRuns = 1;
        for (int run = 0; run < fleuryNumRuns; ++run) {
            clock_t fleuryStart = clock();
            graph.fleuryAlgorithm();
            clock_t fleuryEnd = clock();
            fleuryTotalTime += (fleuryEnd - fleuryStart);
        }
        cout << "Fleury Algorithm - Average Time: " << double(fleuryTotalTime) / CLOCKS_PER_SEC / fleuryNumRuns * 1000000 << " microseconds" << endl;

        cout << "--------------------------------------" << endl;
    }

    return 0;
}
