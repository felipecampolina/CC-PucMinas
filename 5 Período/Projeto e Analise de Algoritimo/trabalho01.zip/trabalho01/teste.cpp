#include <iostream>
#include <vector>
#include <stack>
#include <unordered_set>
#include <ctime>
#include <functional>
#include <thread>
#include <chrono>
#include <algorithm>
using namespace std;

class Graph {
public:
    int vertices;
    vector<unordered_set<int>> adj_list;

    Graph(int v) : vertices(v), adj_list(v) {
        
    }

    void addEdge(int u, int v) {
        adj_list[u].insert(v);
        adj_list[v].insert(u);
    }

    void naiveBridgeDetection();
    void tarjanBridgeDetection();
    void fleuryAlgorithm();
};

void Graph::naiveBridgeDetection() {
    vector<pair<int, int>> bridges;

    for (int u = 0; u < vertices; ++u) {
        for (int v : adj_list[u]) {
            // Criar uma cópia temporária do grafo
            Graph tempGraph = *this;

            // Remover a aresta temporariamente
            tempGraph.adj_list[u].erase(v);
            tempGraph.adj_list[v].erase(u);

            vector<bool> visited(vertices, false);
            stack<int> stack;

            stack.push(0);
            visited[0] = true;

            while (!stack.empty()) {
                int current = stack.top();
                stack.pop();

                for (int neighbor : tempGraph.adj_list[current]) {
                    if (!visited[neighbor]) {
                        stack.push(neighbor);
                        visited[neighbor] = true;
                    }
                }
            }

            // Verificar a conectividade usando uma única busca em profundidade
            if (count(visited.begin(), visited.end(), true) != vertices) {
                bridges.emplace_back(u, v);
            }
        }
    }

    // // Print bridges
    // cout << "Naive Bridges: ";
    // for (auto bridge : bridges) {
    //     cout << "(" << bridge.first << " - " << bridge.second << ") ";
    // }
    // cout << endl;
}

void Graph::tarjanBridgeDetection() {
    vector<pair<int, int>> bridges;
    vector<int> discovery_time(vertices, -1);
    vector<int> low(vertices, -1);
    vector<int> parent(vertices, -1);
    vector<bool> visited(vertices, false);
    int time = 0;

    function<void(int)> dfs = [&](int u) {
        int children = 0;
        visited[u] = true;
        time++;
        discovery_time[u] = low[u] = time;

        for (int v : adj_list[u]) {
            if (!visited[v]) {
                children++;
                parent[v] = u;
                dfs(v);
                low[u] = min(low[u], low[v]);

                if (low[v] > discovery_time[u]) {
                    bridges.emplace_back(u, v);
                }
            } else if (v != parent[u]) {
                low[u] = min(low[u], discovery_time[v]);
            }
        }
    };

    for (int node = 0; node < vertices; ++node) {
        if (!visited[node]) {
            dfs(node);
        }
    }

    // // Print bridges
    // cout << "Tarjan Bridges: ";
    // for (auto bridge : bridges) {
    //     cout << "(" << bridge.first << " - " << bridge.second << ") ";
    // }
    // cout << endl;
}

void Graph::fleuryAlgorithm() {
    vector<int> eulerian_path;
    Graph graph_copy = *this;

    function<bool(int, int)> isValidEdge = [&](int u, int v) {
        return graph_copy.adj_list[u].size() == 1 || (u == v && graph_copy.adj_list[u].size() > 1);
    };

    function<void(int)> dfsFleury;
    dfsFleury = [&](int u) {
        for (int v : graph_copy.adj_list[u]) {
            if (isValidEdge(u, v)) {
                graph_copy.adj_list[u].erase(v);
                graph_copy.adj_list[v].erase(u);
                dfsFleury(v);
            }
        }
        eulerian_path.push_back(u);
    };

    int start_node = 0;
    dfsFleury(start_node);
// Print Eulerian Path
    if (eulerian_path.size() == vertices) {
        cout << "Eulerian Path Found" << endl;
    } else {
        cout << "No Eulerian Path Found" << endl;
    }
}

int main() {
    srand(time(NULL));

    for (int vertices : {1000, 10000, 100000, 1000000}) {
        Graph graph(vertices);

        // Add edges to the graph (assuming it's connected)
        for (int i = 1; i < vertices; ++i) {
            int u = rand() % i;
            graph.addEdge(u, i);
        }

        cout << "Graph with " << vertices << " vertices:" << endl;

        // Medir o tempo para a detecção ingênua de pontes
        clock_t naiveTotalTime = 0;
        int naiveNumRuns = 10;  // Número de execuções para calcular a média
        for (int run = 0; run < naiveNumRuns; ++run) {
            clock_t naiveStart = clock();
            //graph.naiveBridgeDetection();
            clock_t naiveEnd = clock();
            naiveTotalTime += (naiveEnd - naiveStart);
            this_thread::sleep_for(chrono::milliseconds(100));  // Aguarde um curto período entre as execuções
        }
        cout << "Naive method - Average Time: " << double(naiveTotalTime) / CLOCKS_PER_SEC / naiveNumRuns * 1000000 << " microseconds" << endl;

        // Medir o tempo para a detecção de pontes de Tarjan
        clock_t tarjanTotalTime = 0;
        int tarjanNumRuns = 10;
        for (int run = 0; run < tarjanNumRuns; ++run) {
            clock_t tarjanStart = clock();
            graph.tarjanBridgeDetection();
            clock_t tarjanEnd = clock();
            tarjanTotalTime += (tarjanEnd - tarjanStart);
            this_thread::sleep_for(chrono::milliseconds(100));
        }
        cout << "Tarjan method - Average Time: " << double(tarjanTotalTime) / CLOCKS_PER_SEC / tarjanNumRuns * 1000000 << " microseconds" << endl;

        // Medir o tempo para o algoritmo de Fleury
        clock_t fleuryTotalTime = 0;
        int fleuryNumRuns = 10;
        for (int run = 0; run < fleuryNumRuns; ++run) {
            clock_t fleuryStart = clock();
            graph.fleuryAlgorithm();
            clock_t fleuryEnd = clock();
            fleuryTotalTime += (fleuryEnd - fleuryStart);
            this_thread::sleep_for(chrono::milliseconds(100));
        }
        cout << "Fleury Algorithm - Average Time: " << double(fleuryTotalTime) / CLOCKS_PER_SEC / fleuryNumRuns * 1000000 << " microseconds" << endl;

        cout << "--------------------------------------" << endl;
    }

    return 0;
}