package org.arun.cucumber.crudusingdatatable.employee;

public interface ValidationGroups {

  interface CreateEmployee {}

  interface UpdateEmployee {}

}
