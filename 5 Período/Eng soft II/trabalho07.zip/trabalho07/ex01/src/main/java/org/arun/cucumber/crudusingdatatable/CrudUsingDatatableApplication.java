package org.arun.cucumber.crudusingdatatable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudUsingDatatableApplication {

  public static void main(String[] args) {
    SpringApplication.run(CrudUsingDatatableApplication.class, args);
  }

}
