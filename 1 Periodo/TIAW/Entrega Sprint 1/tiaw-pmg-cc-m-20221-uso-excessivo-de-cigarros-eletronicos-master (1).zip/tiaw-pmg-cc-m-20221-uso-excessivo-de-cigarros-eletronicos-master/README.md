[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=7609181&assignment_repo_type=AssignmentRepo)
# Uso excessivo de cigarros eletrônicos
O objetivo geral deste trabalho é a criação de uma plataforma que auxilia as pessoas que fumam cigarros eletrônicos a reduzirem este hábito, visando a interrupção por completa dessa prática, assim reduzindo a prevalência de fumantes e a consequente morbimortalidade relacionada ao consumo de derivados do tabaco.

## Alunos integrantes da equipe

* Arthur de Sá Camargo
* Arthur Sgarbi Andrade
* Felipe Campolina Soares de Paula
* Pedro Gustavo de Castro Markiewicz
* Rafael Lana Mascarenhas Diegues

## Professores responsáveis

* Rommel Vieira Carneiro
* Carlos Alberto Marques Pietrobon
* Daniel de Oliveira Capanema
* Felipe Domingos da Cunha
* Fernanda Farinelli
* Ilo Amy Saldanha Rivero
* João Carlos Oliveira Caetano
* Walisson Ferreira de Carvalho

## Instruções de utilização

Assim que a primeira versão do sistema estiver disponível, deverá complementar com as instruções de utilização. Descreva como instalar eventuais dependências e como executar a aplicação.
