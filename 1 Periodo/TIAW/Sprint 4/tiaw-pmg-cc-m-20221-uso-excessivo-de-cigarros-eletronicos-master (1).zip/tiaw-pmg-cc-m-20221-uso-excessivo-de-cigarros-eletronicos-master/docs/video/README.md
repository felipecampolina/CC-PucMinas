# Vídeos do Projeto
A relação abaixo lista os vídeos feitos para o projeto:
 - [Vídeo Final](https://youtu.be/60zi0IucyDM)


> Nesta pasta inclua arquivos de vídeo produzidos para divulgação do 
> projeto e seus resutados.

