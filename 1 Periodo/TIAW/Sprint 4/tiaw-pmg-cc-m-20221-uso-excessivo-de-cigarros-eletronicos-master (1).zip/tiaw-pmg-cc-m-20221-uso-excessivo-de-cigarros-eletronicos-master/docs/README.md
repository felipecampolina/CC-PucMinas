# Documentação do Projeto

A documentação do projeto é composta pelos seguintes itens: 
 - [Processo de Design Thinking](concepcao/Processo%20Design%20Thinking%201.pdf)
 - [Relatório Técnico](relatorio/Documentação%20TIAW%20.md)
 - [Apresentação do Projeto](apresentacao/Apresentacao%20-%20QuitVapingNow.pptx)
 - [Vídeo de Demonstração](https://youtube.com)

